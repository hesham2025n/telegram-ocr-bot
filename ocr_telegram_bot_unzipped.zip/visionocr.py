
def read_image(filepath):
    # هذا مجرد نموذج مؤقت
    return "OCR result (test only). Replace with Google Vision OCR."
