VISION_KEY_PATH = 'vision-key.json'
BOT_KEY = '8166941860:AAFnmDwugR0r4GhmIgDlmWyGvju6igy7OrE'
